module Assign_05 {

    requires java.desktop;
    requires javafx.base;
    requires javafx.fxml;
    requires javafx.controls;

    opens edu.cuny.ccny.csc221.a5;
}